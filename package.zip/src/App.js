import './App.css';
import TopArtists from './components/Avgtime-listening';
import Search from './components/Search';
import SideBar from './components/SideBar';

function App() {
  return (
    <div className="App">
      <SideBar />
      <Search />
      <TopArtists />
    </div>
  );
}

export default App;
