import './Search.css'

function Search(){
    return(
        <div className = 'search'>
            <p>Search</p>
        </div>
    )
}

export default Search;