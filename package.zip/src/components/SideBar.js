// import { useState } from "react";
import './SideBar.css'

function SideBar(){
return (
    <div className='sidebar'>
        <div className='sidebar-up'>
            <div className='logo'>
                <img src = "logo.png" alt = 'logo' />
                <h1>AHM Music</h1>
            </div>
            <ul className='sidebar-menu'>
                <li>Home</li>
                <li>Recent</li>
            </ul>
        </div>
        <div className='sidebar-down'>
                <ul className = 'sidebar-menu'>
                    <li>Albums</li>
                    <li>Podcasts</li>
                    <li>Favorite</li>
                </ul>
            <div className="contact">
                <i><a href="#" class="fab fa-facebook"></a></i>
                <i><a href="#" class="fab fa-twitter"></a></i>
                <i><a href="#" class="fab fa-instagram"></a></i>
                <i><a href="#" class="fab fa-telegram"></a></i>
            </div>
        </div>
    </div>
  );

}

export default SideBar;