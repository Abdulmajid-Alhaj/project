import data from '../spotify_data.history.json'

function TopArtists(){
    const arr = [...Set(data)]
    return(
        {arr}
    )
}
export default TopArtists;